const { app, BrowserWindow, session, shell } = require('electron')
const path = require('path')
function create() {
  const win = new BrowserWindow({ width: 1280, height: 800, backgroundColor: '#121315', title: 'Air Maps',
    webPreferences: { contextIsolation: true, sandbox: true } })
  // Nominatim/Photon policies want an identifying Referer + User-Agent; file:// pages send none
  session.defaultSession.webRequest.onBeforeSendHeaders(
    { urls: ['https://nominatim.openstreetmap.org/*', 'https://photon.komoot.io/*'] },
    (d, cb) => { d.requestHeaders['Referer'] = 'https://air-maps.local/'; d.requestHeaders['User-Agent'] = 'AirMaps/0.1 (desktop app)'; cb({ requestHeaders: d.requestHeaders }) })
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' } })
  win.loadFile(path.join(__dirname, '../dist/index.html'))
}
app.whenReady().then(() => { create(); app.on('activate', () => { if (!BrowserWindow.getAllWindows().length) create() }) })
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit() })
