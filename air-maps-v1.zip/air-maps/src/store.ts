import { create } from 'zustand'
import type { LayerId, Unit } from './layers'
import type { Bounds } from './lib/grid'
import type { Grid } from './providers'
export interface Sel { lat: number; lon: number; name?: string }
type Theme = 'dark' | 'light'
interface S {
  layer: LayerId; hour: number; unit: Unit; theme: Theme; sel: Sel | null; bounds: Bounds | null
  grid: Grid | null; status: 'idle' | 'loading' | 'error'; error: string; retry: number
  set: (p: Partial<S>) => void
}
const read = (k: string) => { try { return localStorage.getItem(k) } catch { return null } }
const theme0: Theme = read('theme') === 'light' ? 'light' : 'dark'
document.documentElement.dataset.theme = theme0
export const useStore = create<S>((set) => ({
  layer: 'aqi', hour: 0, unit: read('unit') === 'f' ? 'f' : 'c', theme: theme0, sel: null, bounds: null,
  grid: null, status: 'idle', error: '', retry: 0, set: (p) => set(p),
}))
