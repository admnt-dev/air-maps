export interface Sample { frac: number; lat: number; lon: number; temp?: (number | null)[]; rain?: (number | null)[]; aqi?: (number | null)[] }
export interface RouteT { dist: number; dur: number; coords: [number, number][]; samples: Sample[] }
export interface Prefs { aqi: number; temp: number; rain: number }
export interface Metrics { aqi: number | null; temp: number | null; rain: number | null }
const rad = Math.PI / 180
const seg = (a: number[], b: number[]) => Math.hypot((b[0] - a[0]) * Math.cos(((a[1] + b[1]) / 2) * rad), b[1] - a[1])
/** n points evenly spaced by distance along the line (one pass, O(points)). */
export function samplePoints(c: [number, number][], n = 5): Sample[] {
  const cum = [0]
  for (let i = 1; i < c.length; i++) cum.push(cum[i - 1] + seg(c[i - 1], c[i]))
  const tot = cum[cum.length - 1] || 1, out: Sample[] = []
  for (let k = 0, i = 1; k < n; k++) {
    const f = k / (n - 1), t = f * tot
    while (i < c.length - 1 && cum[i] < t) i++
    const a = c[i - 1] ?? c[0], b = c[i] ?? a, c0 = cum[i - 1] ?? 0
    const u = Math.min(1, Math.max(0, (t - c0) / ((cum[i] ?? c0) - c0 || 1)))
    out.push({ frac: f, lon: +(a[0] + (b[0] - a[0]) * u).toFixed(3), lat: +(a[1] + (b[1] - a[1]) * u).toFixed(3) })
  }
  return out
}
/** Conditions at each sample at the hour you'd actually be there (depart + frac * duration). */
export function evaluate(r: RouteT, times: number[], depart: number): Metrics {
  if (!times.length) return { aqi: null, temp: null, rain: null }
  const A: number[] = [], T: number[] = [], R: number[] = []
  for (const s of r.samples) {
    const i = Math.min(times.length - 1, Math.max(0, Math.round((depart + s.frac * r.dur * 1000 - times[0]) / 3.6e6)))
    const a = s.aqi?.[i], t = s.temp?.[i], q = s.rain?.[i]
    if (a != null) A.push(a)
    if (t != null) T.push(t)
    if (q != null) R.push(q)
  }
  const av = (x: number[]) => (x.length ? x.reduce((p, q) => p + q) / x.length : null)
  return { aqi: av(A), temp: av(T), rain: R.length ? Math.max(...R) : null }
}
const c01 = (x: number) => Math.min(1, Math.max(0, x))
/** Lower is better. aqi: importance 0-100. temp: target °C. rain: -100 avoid .. +100 seek. */
export function cost(m: Metrics, dur: number, minDur: number, p: Prefs): number {
  const aq = c01((m.aqi ?? 0) / 150) * (p.aqi / 100)
  const tp = c01(Math.abs((m.temp ?? p.temp) - p.temp) / 15) * 0.7
  const q = (m.rain ?? 0) / 100, rn = (p.rain < 0 ? q : 1 - q) * (Math.abs(p.rain) / 100)
  return aq + tp + rn + c01((dur - minDur) / Math.max(minDur, 1)) * 0.8
}
