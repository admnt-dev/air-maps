export interface Bounds { w: number; s: number; e: number; n: number }
export interface Cell { lat: number; lon: number; poly: number[][] }
const STEPS = [0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 20]
/** Round bounds outward to a nice step so small pans hit the cache. */
export function snapBounds(b: Bounds): Bounds {
  const span = Math.max(b.e - b.w, b.n - b.s)
  const st = STEPS.find((s) => s >= span / 12) ?? 30
  return { w: Math.floor(b.w / st) * st, s: Math.floor(b.s / st) * st, e: Math.ceil(b.e / st) * st, n: Math.ceil(b.n / st) * st }
}
const r3 = (x: number) => Math.round(x * 1000) / 1000
const clamp = (x: number, a: number, b: number) => Math.min(b, Math.max(a, x))
export function makeGrid(b: Bounds, cols = 8, rows = 6): Cell[] {
  const dx = (b.e - b.w) / cols, dy = (b.n - b.s) / rows, out: Cell[] = []
  for (let r = 0; r < rows; r++)
    for (let c = 0; c < cols; c++) {
      const w = b.w + dx * c, s = b.s + dy * r
      out.push({
        lat: r3(clamp(s + dy / 2, -85, 85)), lon: r3(clamp(w + dx / 2, -180, 180)),
        poly: [[w, s], [w + dx, s], [w + dx, s + dy], [w, s + dy], [w, s]],
      })
    }
  return out
}
