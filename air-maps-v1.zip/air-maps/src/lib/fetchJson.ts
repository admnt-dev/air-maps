const cache = new Map<string, { v: unknown; t: number }>()
const inflight = new Map<string, Promise<unknown>>()
const abortErr = () => new DOMException('Aborted', 'AbortError')
const race = <T,>(p: Promise<T>, s: AbortSignal) =>
  new Promise<T>((res, rej) => {
    if (s.aborted) return rej(abortErr())
    s.addEventListener('abort', () => rej(abortErr()))
    p.then(res, rej)
  })
/** GET JSON with LRU cache (TTL ms), in-flight dedupe and per-caller abort. */
export async function fetchJson<T>(url: string, o: { ttl?: number; signal?: AbortSignal } = {}): Promise<T> {
  const hit = cache.get(url)
  if (hit && Date.now() - hit.t < (o.ttl ?? 600_000)) {
    cache.delete(url); cache.set(url, hit)
    return hit.v as T
  }
  let p = inflight.get(url) as Promise<T> | undefined
  if (!p) {
    p = fetch(url)
      .then(async (r) => { if (!r.ok) throw new Error(`HTTP ${r.status}`); return (await r.json()) as T })
      .then((v) => {
        cache.set(url, { v, t: Date.now() })
        if (cache.size > 100) cache.delete(cache.keys().next().value as string)
        return v
      })
      .finally(() => inflight.delete(url))
    inflight.set(url, p)
  }
  return o.signal ? race(p, o.signal) : p
}
