import { describe, expect, it } from 'vitest'
import { makeGrid, snapBounds } from './lib/grid'
import { LAYERS, colorFor, toF } from './layers'
describe('grid', () => {
  it('snaps bounds outward and builds <=64 cells', () => {
    const b = snapBounds({ w: 54.93, s: 24.91, e: 55.62, n: 25.37 })
    expect(b.w).toBeLessThanOrEqual(54.93); expect(b.n).toBeGreaterThanOrEqual(25.37)
    expect(makeGrid(b)).toHaveLength(48)
  })
})
describe('layers', () => {
  it('categorises', () => {
    expect(LAYERS.aqi.category(42)).toBe('Good'); expect(LAYERS.uv.category(8)).toBe('Very high'); expect(toF(100)).toBe(212)
  })
  it('colours stay within the scale', () => { expect(colorFor(LAYERS.rain, -5)).toBe(LAYERS.rain.stops[0][1]) })
})
