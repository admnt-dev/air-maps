export type LayerId = 'aqi' | 'rain' | 'temp' | 'uv'
export type Unit = 'c' | 'f'
export interface LayerDef {
  id: LayerId; label: string; api: 'wx' | 'aq'; variable: string; unit: string; title: string
  stops: [number, string][]; ticks: number[]
  fmt: (v: number, u: Unit) => string; category: (v: number) => string; note?: (v: number) => string
}
// viridis-style stops (colour-blind safe); numbers + labels always shown alongside
const V = ['#482878', '#3e4a89', '#26828e', '#35b779', '#b5de2b', '#fde725']
const ramp = (vals: number[]): [number, string][] => vals.map((v, i) => [v, V[i]])
const pick = (v: number, t: [number, string][]) => (t.find(([m]) => v <= m) ?? t[t.length - 1])[1]
export const toF = (c: number) => (c * 9) / 5 + 32
export const LAYERS: Record<LayerId, LayerDef> = {
  aqi: {
    id: 'aqi', label: 'Air quality', api: 'aq', variable: 'us_aqi', unit: 'US AQI', title: 'Air quality',
    stops: ramp([0, 50, 100, 150, 200, 300]), ticks: [0, 50, 100, 150, 200, 300],
    fmt: (v) => String(Math.round(v)),
    category: (v) => pick(v, [[50, 'Good'], [100, 'Moderate'], [150, 'Unhealthy for sensitive groups'], [200, 'Unhealthy'], [300, 'Very unhealthy'], [999, 'Hazardous']]),
  },
  rain: {
    id: 'rain', label: 'Rain', api: 'wx', variable: 'precipitation_probability', unit: '%', title: 'Chance of rain',
    stops: ramp([0, 20, 40, 60, 80, 100]), ticks: [0, 20, 40, 60, 80, 100],
    fmt: (v) => `${Math.round(v)}%`,
    category: (v) => pick(v, [[10, 'Unlikely'], [30, 'Slight chance'], [60, 'Possible'], [85, 'Likely'], [100, 'Very likely']]),
  },
  temp: {
    id: 'temp', label: 'Temp', api: 'wx', variable: 'temperature_2m', unit: '°', title: 'Temperature',
    stops: ramp([-10, 0, 10, 20, 30, 40]), ticks: [-10, 0, 10, 20, 30, 40],
    fmt: (v, u) => (u === 'f' ? `${Math.round(toF(v))}°F` : `${Math.round(v)}°C`),
    category: (v) => pick(v, [[0, 'Freezing'], [10, 'Cold'], [18, 'Cool'], [26, 'Mild'], [33, 'Warm'], [99, 'Hot']]),
  },
  uv: {
    id: 'uv', label: 'UV', api: 'wx', variable: 'uv_index', unit: 'UV', title: 'UV index',
    stops: ramp([0, 2, 5, 7, 10, 12]), ticks: [0, 2, 5, 7, 10, 12],
    fmt: (v) => v.toFixed(1),
    category: (v) => pick(Math.round(v), [[2, 'Low'], [5, 'Moderate'], [7, 'High'], [10, 'Very high'], [99, 'Extreme']]),
    note: (v) => (v < 3 ? 'No protection needed for most people.' : v < 6 ? 'Wear sunscreen and sunglasses; seek shade at midday.' : v < 8 ? 'Cover up, SPF 30+, limit midday sun.' : 'Avoid midday sun; full protection essential.'),
  },
}
export const ORDER: LayerId[] = ['aqi', 'rain', 'temp', 'uv']
const hex = (h: string) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16))
export function colorFor(l: LayerDef, v: number): string {
  const s = l.stops
  if (v <= s[0][0]) return s[0][1]
  for (let i = 1; i < s.length; i++)
    if (v <= s[i][0]) {
      const t = (v - s[i - 1][0]) / (s[i][0] - s[i - 1][0]), a = hex(s[i - 1][1]), b = hex(s[i][1])
      return `rgb(${a.map((x, k) => Math.round(x + (b[k] - x) * t)).join(',')})`
    }
  return s[s.length - 1][1]
}
