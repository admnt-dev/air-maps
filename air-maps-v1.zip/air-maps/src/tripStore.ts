import { create } from 'zustand'
import type { Sel } from './store'
import type { Prefs, RouteT } from './lib/route'
import type { Mode } from './providers'
interface T {
  open: boolean; from: Sel | null; to: Sel | null; mode: Mode; routes: RouteT[]; times: number[]; notes: string[]
  status: 'idle' | 'loading' | 'error'; error: string; prefs: Prefs; pick: number | null; active: number
}
export const useTrip = create<T>(() => ({ open: false, from: null, to: null, mode: 'car', routes: [], times: [], notes: [],
  status: 'idle', error: '', prefs: { aqi: 60, temp: 22, rain: -60 }, pick: null, active: 0 }))
