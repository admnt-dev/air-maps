import { fetchJson } from './lib/fetchJson'
import type { Cell } from './lib/grid'
import type { LayerDef } from './layers'
const env = import.meta.env
const WX = env.VITE_WEATHER_URL ?? 'https://api.open-meteo.com'
const AQ = env.VITE_AQ_URL ?? 'https://air-quality-api.open-meteo.com'
const PHOTON = env.VITE_PHOTON_URL ?? 'https://photon.komoot.io'
const NOM = env.VITE_NOMINATIM_URL ?? 'https://nominatim.openstreetmap.org'
const TTL = 12 * 60_000
type Hourly = { time: string[]; [k: string]: (number | null)[] | string[] }
type Res = { hourly: Hourly }
const many = async (base: string, path: string, lats: number[], lons: number[], vars: string, signal?: AbortSignal) => {
  const u = `${base}${path}?latitude=${lats.join(',')}&longitude=${lons.join(',')}&hourly=${vars}&forecast_hours=48&timezone=UTC`
  const j = await fetchJson<Res | Res[]>(u, { ttl: TTL, signal })
  return Array.isArray(j) ? j : [j]
}
const iso = (t: string) => Date.parse(t + 'Z')
export interface Grid { layer: LayerDef['id']; cells: Cell[]; values: (number | null)[][]; times: number[]; fetchedAt: number }
/** One multi-coordinate request, only the active layer's variable. */
export async function fetchGrid(l: LayerDef, cells: Cell[], signal: AbortSignal): Promise<Grid> {
  const res = await many(l.api === 'aq' ? AQ : WX, l.api === 'aq' ? '/v1/air-quality' : '/v1/forecast',
    cells.map((c) => c.lat), cells.map((c) => c.lon), l.variable, signal)
  if (res.length !== cells.length) throw new Error('Provider returned an unexpected number of points')
  return { layer: l.id, cells, fetchedAt: Date.now(), times: res[0].hourly.time.map(iso),
    values: res.map((r) => r.hourly[l.variable] as (number | null)[]) }
}
export interface PointData { times: number[]; wx?: Record<string, (number | null)[]>; aq?: Record<string, (number | null)[]>; errors: string[] }
export async function fetchPoint(lat: number, lon: number, signal: AbortSignal): Promise<PointData> {
  const [w, a] = await Promise.allSettled([
    many(WX, '/v1/forecast', [lat], [lon], 'temperature_2m,precipitation_probability,precipitation,uv_index', signal),
    many(AQ, '/v1/air-quality', [lat], [lon], 'us_aqi,pm2_5,pm10', signal),
  ])
  const out: PointData = { times: [], errors: [] }
  if (w.status === 'fulfilled') { out.wx = w.value[0].hourly as never; out.times = w.value[0].hourly.time.map(iso) }
  else if ((w.reason as Error).name !== 'AbortError') out.errors.push('Open-Meteo forecast: ' + (w.reason as Error).message)
  if (a.status === 'fulfilled') { out.aq = a.value[0].hourly as never; if (!out.times.length) out.times = a.value[0].hourly.time.map(iso) }
  else if ((a.reason as Error).name !== 'AbortError') out.errors.push('Open-Meteo air quality: ' + (a.reason as Error).message)
  return out
}
export interface Place { name: string; sub: string; lat: number; lon: number }
type PF = { properties: Record<string, string>; geometry: { coordinates: [number, number] } }
export async function searchPlaces(q: string, signal: AbortSignal): Promise<Place[]> {
  const j = await fetchJson<{ features: PF[] }>(`${PHOTON}/api/?q=${encodeURIComponent(q)}&limit=6`, { ttl: 3_600_000, signal })
  return j.features.map((f) => {
    const p = f.properties
    return { name: p.name ?? p.street ?? q, sub: [p.city, p.state, p.country].filter((x) => x && x !== p.name).join(', '),
      lat: f.geometry.coordinates[1], lon: f.geometry.coordinates[0] }
  })
}
let last = 0
export async function reverse(lat: number, lon: number, signal: AbortSignal): Promise<string | null> {
  const wait = Math.max(0, last + 1100 - Date.now()); last = Date.now() + wait
  if (wait) await new Promise((r) => setTimeout(r, wait))
  if (signal.aborted) return null
  try {
    const j = await fetchJson<{ display_name?: string }>(`${NOM}/reverse?format=jsonv2&zoom=14&lat=${lat}&lon=${lon}`, { ttl: 3_600_000, signal })
    return j.display_name ?? null
  } catch { return null }
}

import { samplePoints, type RouteT } from './lib/route'
const ROUTE = env.VITE_ROUTING_URL ?? 'https://routing.openstreetmap.de'
export type Mode = 'foot' | 'bike' | 'car'
type OsrmRes = { code: string; routes?: { distance: number; duration: number; geometry: { coordinates: [number, number][] } }[] }
/** OSRM routes (+alternatives) then ONE multi-point request per provider for 5 samples/route. */
export async function fetchRoutes(a: { lat: number; lon: number }, b: { lat: number; lon: number }, mode: Mode, signal: AbortSignal) {
  const j = await fetchJson<OsrmRes>(`${ROUTE}/routed-${mode}/route/v1/driving/${a.lon},${a.lat};${b.lon},${b.lat}?alternatives=true&overview=full&geometries=geojson`, { ttl: 300_000, signal })
  if (j.code !== 'Ok' || !j.routes?.length) throw new Error(j.code === 'NoRoute' ? 'No route found between these points for this mode.' : `Routing failed (${j.code}).`)
  const routes: RouteT[] = j.routes.map((r) => ({ dist: r.distance, dur: r.duration, coords: r.geometry.coordinates, samples: samplePoints(r.geometry.coordinates) }))
  const pts = routes.flatMap((r) => r.samples), la = pts.map((p) => p.lat), lo = pts.map((p) => p.lon)
  const [w, q] = await Promise.allSettled([many(WX, '/v1/forecast', la, lo, 'temperature_2m,precipitation_probability', signal), many(AQ, '/v1/air-quality', la, lo, 'us_aqi', signal)])
  const notes: string[] = []
  type H = Record<string, (number | null)[]>
  pts.forEach((p, i) => {
    if (w.status === 'fulfilled') { const h = w.value[i].hourly as unknown as H; p.temp = h.temperature_2m; p.rain = h.precipitation_probability }
    if (q.status === 'fulfilled') p.aqi = (q.value[i].hourly as unknown as H).us_aqi
  })
  if (w.status === 'rejected') notes.push('Weather unavailable (Open-Meteo forecast).')
  if (q.status === 'rejected') notes.push('Air quality unavailable (Open-Meteo).')
  const ok = w.status === 'fulfilled' ? w.value : q.status === 'fulfilled' ? q.value : []
  return { routes, notes, times: ok[0]?.hourly.time.map(iso) ?? [] }
}
