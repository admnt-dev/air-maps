import { useLayoutEffect, useRef, type PointerEvent as RPE, type ReactNode } from 'react'
interface Init { x?: number; r?: number; y?: number; b?: number; w?: number }
interface Rect { x: number; y: number; w: number | null; h: number | null }
interface Props { id: string; init: () => Init; minW?: number; maxW?: number; minH?: number; maxH?: number; rzH?: boolean
  scale?: boolean; high?: boolean; resizable?: boolean; cls?: string; children: ReactNode }
let zTop = 10
const SIDES = ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw']
const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v))

/** Draggable + resizable wrapper. Drag from any non-interactive part; resize from edges/corners within min/max. Layout is remembered. */
export function Float({ id, init, minW = 0, maxW = 9999, minH = 100, maxH = 9999, rzH, scale, high, resizable = true, cls, children }: Props) {
  const el = useRef<HTMLDivElement>(null), body = useRef<HTMLDivElement>(null)
  const rect = useRef<Rect>({ x: 0, y: 0, w: null, h: null }), base = useRef(1), moved = useRef(false)
  const apply = () => {
    const e = el.current!, r = rect.current
    e.style.left = r.x + 'px'; e.style.top = r.y + 'px'
    e.style.width = r.w ? r.w + 'px' : ''; e.style.maxHeight = r.h ? r.h + 'px' : ''
    if (scale && r.w) e.style.setProperty('--s', String(r.w / base.current))
  }
  const fit = () => {
    const e = el.current!, r = rect.current
    r.x = clamp(r.x, 0, Math.max(0, innerWidth - e.offsetWidth)); r.y = clamp(r.y, 0, Math.max(0, innerHeight - e.offsetHeight))
  }
  const save = () => { try { localStorage.setItem('ui:' + id, JSON.stringify(rect.current)) } catch { /* private mode */ } }

  useLayoutEffect(() => {
    const e = el.current!, i = init()
    let saved: Rect | null = null
    try { saved = JSON.parse(localStorage.getItem('ui:' + id) ?? 'null') } catch { /* ignore */ }
    base.current = i.w ?? e.offsetWidth
    if (saved && Number.isFinite(saved.x) && Number.isFinite(saved.y)) rect.current = { x: saved.x, y: saved.y, w: saved.w ?? null, h: saved.h ?? null }
    else rect.current = { x: 0, y: 0, w: i.w ?? null, h: null }
    apply()
    if (!saved) { const r = rect.current; r.x = i.x ?? innerWidth - e.offsetWidth - (i.r ?? 0); r.y = i.y ?? innerHeight - e.offsetHeight - (i.b ?? 0) }
    fit(); apply()
    const on = () => { fit(); apply() }
    addEventListener('resize', on)
    return () => removeEventListener('resize', on)
  }, [])

  const down = (ev: RPE) => {
    if (!high) el.current!.style.zIndex = String((zTop = Math.min(90, zTop + 1)))
    moved.current = false
    const t = ev.target as HTMLElement
    if (ev.button !== 0 || t.closest('.rz,input,textarea,select,a,label,[data-nodrag]') || (t.closest('button') && !t.closest('[data-grab]'))) return
    const sx = ev.clientX, sy = ev.clientY, x0 = rect.current.x, y0 = rect.current.y
    const mv = (m: PointerEvent) => {
      const dx = m.clientX - sx, dy = m.clientY - sy
      if (!moved.current && Math.hypot(dx, dy) < 4) return
      moved.current = true; rect.current.x = x0 + dx; rect.current.y = y0 + dy; fit(); apply()
    }
    const up = () => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); if (moved.current) save() }
    addEventListener('pointermove', mv); addEventListener('pointerup', up)
  }

  const rz = (side: string) => (ev: RPE) => {
    ev.preventDefault()
    const e = el.current!, sx = ev.clientX, sy = ev.clientY, x0 = rect.current.x, y0 = rect.current.y, w0 = e.offsetWidth, h0 = e.offsetHeight
    const cap = Math.min(maxH, body.current!.scrollHeight)
    const hh = (v: number) => clamp(v, Math.min(minH, cap), cap), ww = (v: number) => clamp(v, minW, Math.min(maxW, innerWidth))
    const mv = (m: PointerEvent) => {
      const dx = m.clientX - sx, dy = m.clientY - sy, r = rect.current
      if (side.includes('e')) r.w = ww(w0 + dx)
      if (side.includes('w')) { r.w = ww(w0 - dx); r.x = x0 + w0 - r.w }
      if (side.includes('s')) r.h = hh(h0 + dy)
      if (side.includes('n')) { r.h = hh(h0 - dy); r.y = y0 + h0 - r.h }
      apply()
    }
    const up = () => { removeEventListener('pointermove', mv); removeEventListener('pointerup', up); fit(); apply(); save() }
    addEventListener('pointermove', mv); addEventListener('pointerup', up)
  }

  const sides: readonly string[] = rzH ? SIDES : ['e', 'w']
  return (
    <div ref={el} className={'fl' + (cls ? ' ' + cls : '')} style={{ zIndex: high ? 100 : undefined }} onPointerDownCapture={down}
      onClickCapture={(e) => { if (moved.current) { e.stopPropagation(); e.preventDefault(); moved.current = false } }}>
      <div ref={body} className="fb">{children}</div>
      {resizable && sides.map((s) => <i key={s} className={'rz ' + s} onPointerDown={rz(s)} />)}
    </div>)
}
