import { describe, expect, it } from 'vitest'
import { cost, samplePoints } from './lib/route'
describe('route', () => {
  it('samples 5 evenly spaced points incl. both ends', () => {
    const s = samplePoints([[0, 0], [1, 0], [2, 0]])
    expect(s).toHaveLength(5); expect(s[0].lon).toBe(0); expect(s[2].lon).toBe(1); expect(s[4].lon).toBe(2)
  })
  it('prefers dry route when avoiding rain, wet when seeking', () => {
    const p = { aqi: 0, temp: 22, rain: -100 }, dry = { aqi: null, temp: 22, rain: 5 }, wet = { aqi: null, temp: 22, rain: 80 }
    expect(cost(dry, 600, 600, p)).toBeLessThan(cost(wet, 600, 600, p))
    expect(cost(wet, 600, 600, { ...p, rain: 100 })).toBeLessThan(cost(dry, 600, 600, { ...p, rain: 100 }))
  })
})
