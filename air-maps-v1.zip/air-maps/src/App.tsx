import { Suspense, lazy, useEffect, useRef, useState } from 'react'
import maplibregl, { type GeoJSONSource, type Map as MLMap } from 'maplibre-gl'
import { Crosshair, Moon, Search, Sun, X } from 'lucide-react'
import { Float } from './Float'
import { style, applyTheme } from './map/style'
import { useStore, type Sel } from './store'
import { useTrip } from './tripStore'
import { LAYERS, ORDER, colorFor, toF } from './layers'
import { fetchGrid, fetchPoint, reverse, searchPlaces, type PointData, type Place } from './providers'
import { makeGrid, snapBounds } from './lib/grid'

const Trip = lazy(() => import('./Trip'))
const reduced = () => matchMedia('(prefers-reduced-motion: reduce)').matches
const fmtTime = (t: number) => new Date(t).toLocaleString([], { weekday: 'short', hour: '2-digit', minute: '2-digit' })

function MapView() {
  const el = useRef<HTMLDivElement>(null)
  const map = useRef<MLMap | null>(null)
  const marker = useRef<maplibregl.Marker | null>(null)
  const ready = useRef(false)
  const layer = useStore((s) => s.layer), bounds = useStore((s) => s.bounds), retry = useStore((s) => s.retry)
  const grid = useStore((s) => s.grid), hour = useStore((s) => s.hour), sel = useStore((s) => s.sel)
  const set = useStore((s) => s.set)
  const theme = useStore((s) => s.theme)
  const routes = useTrip((s) => s.routes), active = useTrip((s) => s.active), from = useTrip((s) => s.from), to = useTrip((s) => s.to)
  const fm = useRef<maplibregl.Marker | null>(null), tm = useRef<maplibregl.Marker | null>(null)
  const roads = useRef<{ g: maplibregl.MapGeoJSONFeature['geometry']; k: number; lon: number; lat: number }[]>([])
  const dirty = useRef(false)
  // give each visible road to the forecast cell it sits in (cheap lookup on the regular grid)
  const applyRoads = () => {
    const g = useStore.getState().grid, m = map.current
    if (!m || !ready.current || !g || g.cells.length < 48) return
    const a = g.cells[0].poly[0], b = g.cells[47].poly[2], dx = (b[0] - a[0]) / 8, dy = (b[1] - a[1]) / 6
    const features = roads.current.flatMap((r) => {
      const c = Math.floor((r.lon - a[0]) / dx), w = Math.floor((r.lat - a[1]) / dy)
      return c < 0 || c > 7 || w < 0 || w > 5 ? [] : [{ type: 'Feature' as const, properties: { cell: w * 8 + c, k: r.k }, geometry: r.g }]
    })
    ;(m.getSource('roads') as GeoJSONSource).setData({ type: 'FeatureCollection', features })
  }
  const collect = () => {
    const m = map.current
    if (!m) return
    roads.current = m.queryRenderedFeatures({ layers: ['r-minor', 'r-tert', 'r-major'] }).slice(0, 6000).flatMap((f) => {
      const g = f.geometry, c = g.type === 'LineString' ? g.coordinates : g.type === 'MultiLineString' ? g.coordinates[0] : null
      const p = c?.[c.length >> 1]
      return p ? [{ g, k: f.layer.id === 'r-major' ? 1 : 0, lon: p[0], lat: p[1] }] : []
    })
    applyRoads()
  }

  useEffect(() => {
    const m = new maplibregl.Map({ container: el.current!, style, center: [55.27, 25.2], zoom: 9, attributionControl: false, dragRotate: false })
    map.current = m
    m.addControl(new maplibregl.AttributionControl({ compact: true, customAttribution:
      '<a href="https://open-meteo.com">Weather &amp; air quality: Open-Meteo (CC BY 4.0)</a> | <a href="https://openfreemap.org">OpenFreeMap</a> <a href="https://www.openmaptiles.org">© OpenMapTiles</a> | Data © <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors | Search: Photon, Nominatim' }), 'bottom-right')
    m.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'bottom-right')
    let t: number
    const upd = () => { clearTimeout(t); t = window.setTimeout(() => { const b = m.getBounds(); set({ bounds: snapBounds({ w: b.getWest(), s: b.getSouth(), e: b.getEast(), n: b.getNorth() }) }) }, 400) }
    m.on('load', () => {
      const empty = { type: 'FeatureCollection' as const, features: [] }, d = reduced() ? 0 : 200
      m.addSource('roads', { type: 'geojson', data: empty }); m.addSource('route', { type: 'geojson', data: empty })
      const k = ['match', ['get', 'k'], 1, 1.5, 0.7]
      m.addLayer({ id: 'roads', type: 'line', source: 'roads', layout: { 'line-cap': 'round', 'line-join': 'round' },
        paint: { 'line-color': 'rgba(0,0,0,0)', 'line-opacity': 0, 'line-opacity-transition': { duration: d }, 'line-color-transition': { duration: d },
          'line-width': ['interpolate', ['exponential', 1.4], ['zoom'], 4, ['*', k, 0.8], 12, ['*', k, 2.6], 18, ['*', k, 11]] as never } }, 'place')
      const ln = (id: string, color: string, w: number, f: unknown) => m.addLayer({ id, type: 'line', source: 'route', filter: f as never,
        layout: { 'line-cap': 'round', 'line-join': 'round' }, paint: { 'line-color': color, 'line-width': w } }, 'place')
      ln('route-case', '#0b0c0d', 9, ['has', 'a']); ln('route-alt', '#9aa0a8', 4, ['==', ['get', 'a'], 0]); ln('route', '#ffffff', 5, ['==', ['get', 'a'], 1])
      applyTheme(m, useStore.getState().theme); ready.current = true; dirty.current = true; upd(); m.on('moveend', () => { upd(); dirty.current = true })
    })
    m.on('idle', () => { if (dirty.current) { dirty.current = false; collect() } })
    m.on('click', (e) => set({ sel: { lat: +e.lngLat.lat.toFixed(4), lon: +e.lngLat.lng.toFixed(4) } }))
    return () => { clearTimeout(t); m.remove(); map.current = null; ready.current = false }
  }, [set])

  // fetch grid for the active layer only (cached, deduped, abortable)
  useEffect(() => {
    if (!bounds) return
    const m = map.current, ac = new AbortController()
    if (m && ready.current && useStore.getState().grid?.layer !== layer) m.setPaintProperty('roads', 'line-opacity', 0)
    set({ status: 'loading', error: '' })
    fetchGrid(LAYERS[layer], makeGrid(bounds), ac.signal)
      .then((g) => set({ grid: g, status: 'idle' }))
      .catch((e: Error) => { if (e.name !== 'AbortError') set({ status: 'error', error: `${LAYERS[layer].api === 'aq' ? 'Open-Meteo air quality' : 'Open-Meteo forecast'}: ${e.message}` }) })
    return () => ac.abort()
  }, [layer, bounds, retry, set])

  // roads take the colour of their forecast cell; per hour only a 48-colour array changes (null = no data, stays clear)
  useEffect(() => { const m = map.current; if (m && ready.current) applyTheme(m, theme) }, [theme])
  useEffect(() => { applyRoads() }, [grid])
  useEffect(() => {
    const m = map.current
    if (!m || !ready.current || !grid || grid.layer !== layer) return
    const l = LAYERS[layer]
    const cols = grid.cells.map((_, i) => { const v = grid.values[i]?.[hour]; return v == null ? 'rgba(0,0,0,0)' : colorFor(l, v) })
    m.setPaintProperty('roads', 'line-color', ['to-color', ['at', ['get', 'cell'], ['literal', cols]]] as never)
    m.setPaintProperty('roads', 'line-opacity', 0.95)
  }, [grid, hour, layer])

  useEffect(() => {
    const m = map.current
    if (!m || !ready.current) return
    ;(m.getSource('route') as GeoJSONSource).setData({ type: 'FeatureCollection', features: routes.map((r, i) => ({ type: 'Feature' as const, properties: { a: i === active ? 1 : 0 }, geometry: { type: 'LineString' as const, coordinates: r.coords } })) })
  }, [routes, active])
  useEffect(() => {
    const m = map.current
    if (!m) return
    fm.current?.remove(); tm.current?.remove()
    fm.current = from ? new maplibregl.Marker({ color: '#4cc2ff' }).setLngLat([from.lon, from.lat]).addTo(m) : null
    tm.current = to ? new maplibregl.Marker({ color: '#ffb454' }).setLngLat([to.lon, to.lat]).addTo(m) : null
  }, [from, to])

  useEffect(() => {
    const m = map.current
    if (!m) return
    marker.current?.remove()
    if (sel) marker.current = new maplibregl.Marker({ color: '#4cc2ff' }).setLngLat([sel.lon, sel.lat]).addTo(m)
  }, [sel])

  useEffect(() => {
    const h = (e: Event) => { const p = (e as CustomEvent<Sel>).detail; map.current?.flyTo({ center: [p.lon, p.lat], zoom: 11, animate: !reduced() }) }
    const f = (e: Event) => map.current?.fitBounds((e as CustomEvent<[number, number, number, number]>).detail,
      { padding: innerWidth > 700 ? { top: 90, bottom: 130, left: 300, right: 330 } : 50, animate: !reduced(), maxZoom: 15 })
    window.addEventListener('fly', h); window.addEventListener('fit', f)
    return () => { window.removeEventListener('fly', h); window.removeEventListener('fit', f) }
  }, [])
  return <div ref={el} className="map" aria-label="Map" />
}

function SearchBox() {
  const [q, setQ] = useState(''), [res, setRes] = useState<Place[]>([]), [msg, setMsg] = useState('')
  const set = useStore((s) => s.set)
  useEffect(() => {
    if (q.trim().length < 3) { setRes([]); setMsg(''); return }
    const ac = new AbortController()
    const t = setTimeout(() => searchPlaces(q.trim(), ac.signal).then((r) => { setRes(r); setMsg(r.length ? '' : 'No places found') })
      .catch((e: Error) => { if (e.name !== 'AbortError') setMsg('Search failed (Photon): ' + e.message) }), 350)
    return () => { clearTimeout(t); ac.abort() }
  }, [q])
  const go = (p: Place) => { set({ sel: { lat: p.lat, lon: p.lon, name: [p.name, p.sub].filter(Boolean).join(', ') } }); window.dispatchEvent(new CustomEvent('fly', { detail: p })); setRes([]); setQ('') }
  return (
    <div className="search">
      <Search size={16} aria-hidden />
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search places" aria-label="Search places" />
      {q && <button aria-label="Clear search" onClick={() => setQ('')}><X size={16} /></button>}
      {(res.length > 0 || msg) && (
        <ul role="listbox">{res.map((p, i) => <li key={i}><button onClick={() => go(p)}><b>{p.name}</b> <span>{p.sub}</span></button></li>)}
          {msg && <li className="dim">{msg}</li>}</ul>)}
    </div>)
}

function Layers() {
  const layer = useStore((s) => s.layer), set = useStore((s) => s.set)
  return <nav className="layers" aria-label="Map layer">{ORDER.map((id) =>
    <button key={id} aria-pressed={layer === id} onClick={() => set({ layer: id })}>{LAYERS[id].label}</button>)}</nav>
}

function Legend() {
  const layer = useStore((s) => s.layer), unit = useStore((s) => s.unit), status = useStore((s) => s.status)
  const error = useStore((s) => s.error), set = useStore((s) => s.set)
  const l = LAYERS[layer], f = (v: number) => (layer === 'temp' && unit === 'f' ? Math.round(toF(v)) : v)
  const max = l.stops[l.stops.length - 1][0], min = l.stops[0][0]
  return (
    <section className="legend" aria-label="Legend">
      <div className="row"><b>{l.title}</b>
        {layer === 'temp' && <button className="chip" onClick={() => { const u = unit === 'c' ? 'f' : 'c'; try { localStorage.setItem('unit', u) } catch { /* private mode */ } set({ unit: u }) }}>°{unit === 'c' ? 'C' : 'F'} → °{unit === 'c' ? 'F' : 'C'}</button>}</div>
      <div className="ramp" style={{ background: `linear-gradient(90deg,${l.stops.map(([v, c]) => `${c} ${((v - min) / (max - min)) * 100}%`).join(',')})` }} />
      <div className="ticks">{l.ticks.map((t) => <span key={t}>{f(t)}</span>)}</div>
      {status === 'loading' && <p className="dim" role="status">Loading…</p>}
      {status === 'error' && <p className="err" role="alert">{error} <button className="chip" onClick={() => set({ retry: useStore.getState().retry + 1 })}>Retry</button></p>}
    </section>)
}

function Scrubber() {
  const hour = useStore((s) => s.hour), grid = useStore((s) => s.grid), set = useStore((s) => s.set)
  const n = grid?.times.length ?? 48
  return (
    <div className="scrub">
      <button className="chip" onClick={() => set({ hour: 0 })} disabled={hour === 0}>Now</button>
      <input type="range" min={0} max={n - 1} value={hour} aria-label="Forecast hour" onChange={(e) => set({ hour: +e.target.value })} />
      <time>{grid ? fmtTime(grid.times[hour]) : '—'}</time>
    </div>)
}

function InfoPanel() {
  const sel = useStore((s) => s.sel), layer = useStore((s) => s.layer), hour = useStore((s) => s.hour), unit = useStore((s) => s.unit), set = useStore((s) => s.set)
  const [d, setD] = useState<PointData | null>(null), [name, setName] = useState<string | undefined>()
  useEffect(() => {
    if (!sel) return
    setD(null); setName(sel.name)
    const ac = new AbortController()
    fetchPoint(sel.lat, sel.lon, ac.signal).then(setD).catch(() => undefined)
    if (!sel.name) reverse(sel.lat, sel.lon, ac.signal).then((n) => { if (n) setName(n) })
    return () => ac.abort()
  }, [sel])
  if (!sel) return null
  const l = LAYERS[layer], get = (src: Record<string, (number | null)[]> | undefined, k: string) => src?.[k]?.[hour] ?? null
  const main = get(layer === 'aqi' ? d?.aq : d?.wx, l.variable)
  const rows: [string, string][] = []
  if (layer === 'aqi') rows.push(['PM2.5', fmtV(get(d?.aq, 'pm2_5'), 'µg/m³')], ['PM10', fmtV(get(d?.aq, 'pm10'), 'µg/m³')])
  if (layer === 'rain') rows.push(['Precipitation', fmtV(get(d?.wx, 'precipitation'), 'mm')])
  return (
    <Float id="info" rzH init={() => (innerWidth > 700 ? { r: 60, y: 8, w: 280 } : { x: 0, b: 0, w: innerWidth })} minW={240} maxW={440} minH={140} maxH={640}>
    <aside className="panel" aria-label="Selected location">
      <div className="row"><b className="name">{name ?? `${sel.lat}, ${sel.lon}`}</b><button aria-label="Close" onClick={() => set({ sel: null })}><X size={16} /></button></div>
      <p className="dim">{sel.lat}, {sel.lon}</p>
      <div className="row act"><button className="chip" onClick={() => useTrip.setState({ from: { lat: sel.lat, lon: sel.lon, name }, open: true })}>From here</button>
        <button className="chip" onClick={() => useTrip.setState({ to: { lat: sel.lat, lon: sel.lon, name }, open: true })}>To here</button></div>
      {!d ? <p className="dim" role="status">Loading…</p> : main == null ? <p className="dim">No data for this hour.</p> : (
        <>
          <div className="big">{l.fmt(main, unit)}<span> {layer === 'aqi' ? 'AQI' : layer === 'uv' ? 'UV' : ''}</span></div>
          <p>{l.category(main)}</p>
          {rows.map(([k, v]) => <div className="row dim" key={k}><span>{k}</span><span>{v}</span></div>)}
        </>)}
      {d?.errors.map((e) => <p className="err" key={e}>{e}</p>)}
      <p className="dim">Forecast for {d?.times[hour] ? fmtTime(d.times[hour]) : '—'}</p>
    </aside></Float>)
}
const fmtV = (v: number | null, u: string) => (v == null ? 'no data' : `${v} ${u}`)

export function App() {
  const set = useStore((s) => s.set), theme = useStore((s) => s.theme), [geoErr, setGeoErr] = useState('')
  useEffect(() => { document.documentElement.dataset.theme = theme; try { localStorage.setItem('theme', theme) } catch { /* private mode */ } }, [theme])
  const locate = () => navigator.geolocation.getCurrentPosition(
    (p) => { const s = { lat: +p.coords.latitude.toFixed(4), lon: +p.coords.longitude.toFixed(4) }; set({ sel: s }); window.dispatchEvent(new CustomEvent('fly', { detail: s })); setGeoErr('') },
    (err) => err.code === 1 ? setGeoErr('Location permission denied.') : fetch('https://ipwho.is/').then((r) => r.json())
      .then((j: { success: boolean; latitude: number; longitude: number }) => { if (!j.success) throw new Error('no ip location'); const s = { lat: +j.latitude.toFixed(2), lon: +j.longitude.toFixed(2) }; set({ sel: s }); window.dispatchEvent(new CustomEvent('fly', { detail: s })); setGeoErr('Approximate location (from IP address).') })
      .catch(() => setGeoErr('Location unavailable.')), { timeout: 10000 })
  return (
    <>
      <MapView />
      <Float id="logo" scale init={() => ({ x: 8, y: 8, w: 132 })} minW={90} maxW={320}><div className="logo" aria-label="Air Maps">AIR MAPS</div></Float>
      <Float id="search" high cls="vis" init={() => ({ x: 8, y: 48, w: Math.min(280, innerWidth - 16) })} minW={200} maxW={480}><SearchBox /></Float>
      <Float id="layers" init={() => ({ x: 8, y: 96, w: 112 })} minW={90} maxW={200}><Layers /></Float>
      <Float id="trip" rzH init={() => ({ x: 8, y: 244, w: Math.min(260, innerWidth - 16) })} minW={220} maxW={440} minH={160} maxH={760}>
        <Suspense fallback={null}><Trip /></Suspense></Float>
      <Float id="legend" init={() => ({ x: 8, b: 72, w: Math.min(260, innerWidth - 16) })} minW={200} maxW={420}><Legend /></Float>
      <Float id="time" init={() => { const w = Math.min(520, innerWidth - 16); return { x: (innerWidth - w) / 2, b: 8, w } }} minW={260} maxW={900}><Scrubber /></Float>
      <InfoPanel />
      <Float id="actions" resizable={false} init={() => ({ r: 8, y: 8 })}>
        <div className="acts">
          <button className="icon" aria-label="Show my location" onClick={locate}><Crosshair size={18} /></button>
          <button className="icon" aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'} onClick={() => set({ theme: theme === 'dark' ? 'light' : 'dark' })}>
            {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}</button>
        </div>
      </Float>
      {geoErr && <p className="err toast" role="alert">{geoErr}</p>}
    </>)
}
