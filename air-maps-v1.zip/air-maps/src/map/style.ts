import type { Map as MLMap, StyleSpecification, LayerSpecification } from 'maplibre-gl'
const env = import.meta.env
const road = (id: string, cls: string[], color: string, w: [number, number, number]): LayerSpecification => ({
  id, type: 'line', source: 'om', 'source-layer': 'transportation',
  filter: ['all', ['in', 'class', ...cls], ['!=', 'brunnel', 'tunnel']],
  layout: { 'line-cap': 'round', 'line-join': 'round' },
  paint: { 'line-color': color, 'line-width': ['interpolate', ['exponential', 1.4], ['zoom'], 6, w[0], 12, w[1], 18, w[2]] },
})
/** Flat dark cartographic style for the OpenMapTiles schema (OpenFreeMap). */
export const style: StyleSpecification = {
  version: 8,
  glyphs: env.VITE_GLYPHS_URL ?? 'https://tiles.openfreemap.org/fonts/{fontstack}/{range}.pbf',
  sources: { om: { type: 'vector', url: env.VITE_TILE_URL ?? 'https://tiles.openfreemap.org/planet' } },
  layers: [
    { id: 'bg', type: 'background', paint: { 'background-color': '#1b1d20' } },
    { id: 'park', type: 'fill', source: 'om', 'source-layer': 'park', paint: { 'fill-color': '#1e2321' } },
    { id: 'water', type: 'fill', source: 'om', 'source-layer': 'water', paint: { 'fill-color': '#0e1012' } },
    { id: 'boundary', type: 'line', source: 'om', 'source-layer': 'boundary', filter: ['<=', 'admin_level', 4],
      paint: { 'line-color': '#3a3e44', 'line-width': 0.8, 'line-dasharray': [3, 2] } },
    road('r-minor', ['minor', 'service', 'track'], '#2c2f33', [0.2, 0.8, 4]),
    road('r-tert', ['tertiary', 'secondary'], '#3a3e44', [0.3, 1.4, 8]),
    road('r-major', ['primary', 'trunk', 'motorway'], '#555a61', [0.6, 2.2, 12]),
    { id: 'place', type: 'symbol', source: 'om', 'source-layer': 'place',
      filter: ['in', 'class', 'city', 'town', 'suburb', 'village', 'country'],
      layout: { 'text-field': ['coalesce', ['get', 'name:latin'], ['get', 'name']], 'text-font': ['Noto Sans Regular'],
        'text-size': ['match', ['get', 'class'], 'country', 14, 'city', 13, 11], 'text-max-width': 8 },
      paint: { 'text-color': '#9a9ea5', 'text-halo-color': '#1b1d20', 'text-halo-width': 1.2 } },
  ],
}

const P = {
  dark: { bg: '#1b1d20', park: '#1e2321', water: '#0e1012', bound: '#3a3e44', minor: '#2c2f33', tert: '#3a3e44', major: '#555a61', text: '#9a9ea5', halo: '#1b1d20' },
  light: { bg: '#ebecee', park: '#e0e6e0', water: '#c7d2dc', bound: '#b9bdc4', minor: '#d9dbde', tert: '#c8cbcf', major: '#aeb2b8', text: '#5a5f66', halo: '#ebecee' },
}
/** Swap the base-map palette in place (keeps overlays and map position). */
export function applyTheme(m: MLMap, t: 'dark' | 'light') {
  const c = P[t]
  m.setPaintProperty('bg', 'background-color', c.bg); m.setPaintProperty('park', 'fill-color', c.park); m.setPaintProperty('water', 'fill-color', c.water)
  m.setPaintProperty('boundary', 'line-color', c.bound); m.setPaintProperty('r-minor', 'line-color', c.minor)
  m.setPaintProperty('r-tert', 'line-color', c.tert); m.setPaintProperty('r-major', 'line-color', c.major)
  m.setPaintProperty('place', 'text-color', c.text); m.setPaintProperty('place', 'text-halo-color', c.halo)
}
