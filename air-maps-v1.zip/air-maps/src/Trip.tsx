import { useEffect, useMemo } from 'react'
import { Bike, Car, ChevronDown, Footprints, Route as RouteIcon, X } from 'lucide-react'
import { useTrip } from './tripStore'
import { useStore } from './store'
import { toF } from './layers'
import { fetchRoutes, type Mode } from './providers'
import { cost, evaluate } from './lib/route'

const fmtDur = (s: number) => (s < 3600 ? `${Math.max(1, Math.round(s / 60))} min` : `${Math.floor(s / 3600)} h ${Math.round((s % 3600) / 60)} min`)
const fmtEta = (t: number) => new Date(t).toLocaleString([], { weekday: 'short', hour: '2-digit', minute: '2-digit' })
const MODES: [Mode, typeof Car, string][] = [['foot', Footprints, 'Walk'], ['bike', Bike, 'Cycle'], ['car', Car, 'Drive']]
const set = useTrip.setState

export default function Trip() {
  const open = useTrip((s) => s.open), from = useTrip((s) => s.from), to = useTrip((s) => s.to), mode = useTrip((s) => s.mode)
  const routes = useTrip((s) => s.routes), times = useTrip((s) => s.times), notes = useTrip((s) => s.notes)
  const status = useTrip((s) => s.status), error = useTrip((s) => s.error), prefs = useTrip((s) => s.prefs), pick = useTrip((s) => s.pick)
  const hour = useStore((s) => s.hour), unit = useStore((s) => s.unit)

  useEffect(() => {
    if (!from || !to) { set({ routes: [], status: 'idle', error: '' }); return }
    const ac = new AbortController()
    set({ status: 'loading', error: '', pick: null })
    fetchRoutes(from, to, mode, ac.signal).then((r) => {
      set({ routes: r.routes, times: r.times, notes: r.notes, status: 'idle' })
      let w = 180, s = 90, e = -180, n = -90
      for (const [x, y] of r.routes[0].coords) { w = Math.min(w, x); e = Math.max(e, x); s = Math.min(s, y); n = Math.max(n, y) }
      window.dispatchEvent(new CustomEvent('fit', { detail: [w, s, e, n] }))
    }).catch((e: Error) => { if (e.name !== 'AbortError') set({ status: 'error', error: e.message, routes: [] }) })
    return () => ac.abort()
  }, [from, to, mode])

  // re-scoring is pure maths on cached samples: sliders and the time scrubber never refetch
  const depart = useMemo(() => Date.now() + hour * 3.6e6, [hour, routes])
  const { ev, best } = useMemo(() => {
    const min = Math.min(...routes.map((r) => r.dur))
    const ev = routes.map((r) => { const m = evaluate(r, times, depart); return { r, m, c: cost(m, r.dur, min, prefs) } })
    return { ev, best: ev.reduce((b, x, i) => (x.c < ev[b].c ? i : b), 0) }
  }, [routes, times, depart, prefs])
  const active = pick != null && pick < ev.length ? pick : best
  useEffect(() => { if (useTrip.getState().active !== active) set({ active }) }, [active])

  const T = (c: number) => (unit === 'f' ? `${Math.round(toF(c))}°F` : `${Math.round(c)}°C`)
  const place = (p: typeof from, k: 'from' | 'to', label: string) => (
    <div className="pl"><span className="dim">{label}</span>
      <span className="nm">{p ? p.name ?? `${p.lat}, ${p.lon}` : <i className="dim">Click the map, then “{label} here”</i>}</span>
      {p && <button aria-label={`Clear ${label}`} onClick={() => set({ [k]: null })}><X size={14} /></button>}</div>)
  const sl = (label: string, v: number, min: number, max: number, k: 'aqi' | 'temp' | 'rain', hint: [string, string]) => (
    <label className="sl"><span className="row"><span>{label}</span></span>
      <input type="range" min={min} max={max} value={v} onChange={(e) => set({ prefs: { ...prefs, [k]: +e.target.value } })} />
      <span className="row dim"><span>{hint[0]}</span><span>{hint[1]}</span></span></label>)

  return (
    <section className="trip" aria-label="Trip planner">
      <button className="trip-h" data-grab aria-expanded={open} onClick={() => set({ open: !open })}>
        <RouteIcon size={16} /> Plan a trip <ChevronDown size={16} className={open ? 'up' : ''} /></button>
      <div className={'fold' + (open ? ' on' : '')}><div className="inner"><div className="pad">
        {place(from, 'from', 'From')}{place(to, 'to', 'To')}
        <div className="modes" role="group" aria-label="Travel mode">
          {MODES.map(([m, Icon, l]) => <button key={m} className="chip" aria-pressed={mode === m} onClick={() => set({ mode: m })}><Icon size={14} /> {l}</button>)}</div>
        {sl(`Air quality matters: ${prefs.aqi}%`, prefs.aqi, 0, 100, 'aqi', ['Ignore', 'Lower AQI always wins'])}
        {sl(`Ideal temperature: ${T(prefs.temp)}`, prefs.temp, 0, 45, 'temp', ['Cold', 'Hot'])}
        {sl(prefs.rain < -10 ? `Avoid rain (${-prefs.rain}%)` : prefs.rain > 10 ? `Seek rain (${prefs.rain}%)` : 'Rain: don’t mind', prefs.rain, -100, 100, 'rain', ['Want dry', 'Want rain'])}
        {status === 'loading' && <p className="dim" role="status">Finding routes…</p>}
        {status === 'error' && <p className="err" role="alert">{error} <button className="chip" onClick={() => from && set({ from: { ...from } })}>Retry</button></p>}
        {ev.map(({ r, m }, i) => (
          <button key={i} className={'rt' + (i === active ? ' on' : '')} onClick={() => set({ pick: i })}>
            <span className="row"><b>{fmtDur(r.dur)}</b><span>{(r.dist / 1000).toFixed(1)} km</span></span>
            <span className="dim">ETA {fmtEta(depart + r.dur * 1000)}{i === best ? ' · Best match' : ''}</span>
            <span className="dim">AQI {m.aqi == null ? 'no data' : Math.round(m.aqi)} · Rain up to {m.rain == null ? 'no data' : `${Math.round(m.rain)}%`} · {m.temp == null ? 'no data' : T(m.temp)}</span>
          </button>))}
        {ev.length > 0 && <p className="dim">{ev.length === 1 ? 'Only one route found. ' : ''}Leaving {hour === 0 ? 'now' : fmtEta(depart)}. Use the time slider to change it.</p>}
        {notes.map((n) => <p className="err" key={n}>{n}</p>)}
      </div></div></div>
    </section>)
}
